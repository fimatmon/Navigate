Java8 CUI based game for a console / command prompt.

try on install dir: java -jar Navigate.jar

or install the program on C:\temp\Navigate and hit on Navigate.bat